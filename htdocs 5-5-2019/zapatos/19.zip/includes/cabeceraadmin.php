<p>Administracion</p>
<p> <a href="../admin/productos_lista.php">Lista Productos</a></p>
<p> <a href="../admin/categorias_lista.php">Lista Categorias</a></p>
<p> <a href="../admin/usuarios_lista.php">Lista Usuarios</a></p>
